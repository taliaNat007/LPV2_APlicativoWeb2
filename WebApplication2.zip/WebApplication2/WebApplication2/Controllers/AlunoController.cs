﻿using Microsoft.AspNetCore.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers;

public class AlunoController : Controller
{
    // GET
    public IActionResult Index()
    {
        var alunos = new List<Aluno>()
        {
            new Aluno(){Id=1, Nome="Aluno1", Curso="ADS", Nota=5},
            new Aluno(){Id=1, Nome="Aluno2", Curso="ADS", Nota=6},
            new Aluno(){Id=1, Nome="Aluno3", Curso="ADS", Nota=7},
        };
        
        return View(alunos);
    }
}